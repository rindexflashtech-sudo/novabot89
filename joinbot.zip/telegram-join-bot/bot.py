"""
Join-Request Welcome Bot
------------------------
When someone taps "Request to join" on a private channel/group where this bot
is an admin, the bot instantly sends that person a private message you can edit.

Only one secret is needed: BOT_TOKEN.
"""

import asyncio
import html
import json
import logging
import os
import sqlite3
import time
from contextlib import closing
from functools import wraps
from pathlib import Path

from telegram import (
    BotCommand,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Update,
)
from telegram.constants import ParseMode
from telegram.error import BadRequest, Forbidden, RetryAfter, TelegramError
from telegram.ext import (
    ApplicationBuilder,
    ChatJoinRequestHandler,
    CommandHandler,
    ContextTypes,
    filters,
)

logging.basicConfig(
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    level=logging.INFO,
)
logging.getLogger("httpx").setLevel(logging.WARNING)
log = logging.getLogger("joinbot")

# ----------------------------------------------------------------------------
# Storage (SQLite). On Railway, attach a Volume so data survives redeploys.
# Railway sets RAILWAY_VOLUME_MOUNT_PATH automatically when a volume exists.
# ----------------------------------------------------------------------------
DATA_DIR = Path(
    os.getenv("DATA_DIR") or os.getenv("RAILWAY_VOLUME_MOUNT_PATH") or "./data"
)
DB_PATH = DATA_DIR / "bot.db"

DEFAULT_MESSAGE = (
    "👋 Hi <b>{first_name}</b>!\n\n"
    "Thanks for requesting to join <b>{channel}</b>.\n"
    "Your request has been received."
)
MAX_BUTTONS = 8


def db() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with closing(db()) as c, c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS users (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                first_name TEXT,
                first_seen INTEGER,
                last_seen INTEGER,
                started INTEGER DEFAULT 0,
                blocked INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS requests (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                chat_id INTEGER,
                chat_title TEXT,
                ts INTEGER,
                delivered INTEGER DEFAULT 0,
                approved INTEGER DEFAULT 0
            );
            """
        )


def get_setting(key: str, default=None):
    with closing(db()) as c:
        row = c.execute("SELECT value FROM settings WHERE key = ?", (key,)).fetchone()
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    with closing(db()) as c, c:
        c.execute(
            "INSERT INTO settings (key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value",
            (key, value),
        )


def del_setting(key: str) -> None:
    with closing(db()) as c, c:
        c.execute("DELETE FROM settings WHERE key = ?", (key,))


def upsert_user(user, started: bool = False) -> None:
    now = int(time.time())
    with closing(db()) as c, c:
        c.execute(
            """
            INSERT INTO users (user_id, username, first_name, first_seen, last_seen, started)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                first_name = excluded.first_name,
                last_seen = excluded.last_seen,
                started = MAX(users.started, excluded.started),
                blocked = CASE WHEN excluded.started = 1 THEN 0 ELSE users.blocked END
            """,
            (user.id, user.username, user.first_name, now, now, 1 if started else 0),
        )


def mark_blocked(user_id: int) -> None:
    with closing(db()) as c, c:
        c.execute("UPDATE users SET blocked = 1 WHERE user_id = ?", (user_id,))


def log_request(user_id: int, chat_id: int, title: str, delivered: bool, approved: bool) -> None:
    with closing(db()) as c, c:
        c.execute(
            "INSERT INTO requests (user_id, chat_id, chat_title, ts, delivered, approved) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (user_id, chat_id, title, int(time.time()), int(delivered), int(approved)),
        )


# ----------------------------------------------------------------------------
# Message building
# ----------------------------------------------------------------------------
def get_owner() -> int | None:
    env_owner = os.getenv("OWNER_ID", "").strip()
    if env_owner.isdigit():
        return int(env_owner)
    stored = get_setting("owner_id")
    return int(stored) if stored else None


def get_buttons() -> list[list[str]]:
    raw = get_setting("buttons")
    if not raw:
        return []
    try:
        return json.loads(raw)
    except ValueError:
        return []


def build_markup() -> InlineKeyboardMarkup | None:
    buttons = get_buttons()
    if not buttons:
        return None
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton(text, url=url)] for text, url in buttons]
    )


def render_text(first_name: str, channel: str) -> str:
    text = get_setting("message", DEFAULT_MESSAGE)
    return text.replace("{first_name}", html.escape(first_name or "there")).replace(
        "{channel}", html.escape(channel or "the channel")
    )


async def send_welcome(bot, chat_id: int, first_name: str, channel: str) -> None:
    """Send the configured welcome message (photo + text + buttons)."""
    text = render_text(first_name, channel)
    markup = build_markup()
    photo = get_setting("photo")

    if photo:
        # Photo captions are limited to 1024 chars; HTML length is a safe upper bound.
        if len(text) <= 1024:
            await bot.send_photo(
                chat_id=chat_id,
                photo=photo,
                caption=text,
                parse_mode=ParseMode.HTML,
                reply_markup=markup,
            )
            return
        await bot.send_photo(chat_id=chat_id, photo=photo)

    await bot.send_message(
        chat_id=chat_id,
        text=text,
        parse_mode=ParseMode.HTML,
        reply_markup=markup,
    )


# ----------------------------------------------------------------------------
# The core feature: join requests
# ----------------------------------------------------------------------------
async def on_join_request(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    req = update.chat_join_request
    user = req.from_user
    title = req.chat.title or str(req.chat.id)
    delivered = False
    approved = False

    upsert_user(user)

    # 1) DM the requester. user_chat_id lets the bot message them even if they
    #    never started the bot (valid for ~5 minutes after the request).
    try:
        await send_welcome(context.bot, req.user_chat_id, user.first_name, title)
        delivered = True
    except Forbidden:
        mark_blocked(user.id)
        log.warning("Could not DM %s (blocked or privacy)", user.id)
    except RetryAfter as e:
        await asyncio.sleep(e.retry_after + 1)
        try:
            await send_welcome(context.bot, req.user_chat_id, user.first_name, title)
            delivered = True
        except TelegramError as e2:
            log.error("DM retry failed for %s: %s", user.id, e2)
    except TelegramError as e:
        log.error("DM failed for %s: %s", user.id, e)

    # 2) Optionally approve the request (off by default).
    if get_setting("autoapprove", "off") == "on":
        try:
            await req.approve()
            approved = True
        except BadRequest as e:
            log.warning("Approve failed for %s: %s", user.id, e)
        except TelegramError as e:
            log.error("Approve error for %s: %s", user.id, e)

    log_request(user.id, req.chat.id, title, delivered, approved)
    log.info("Join request user=%s chat=%s delivered=%s approved=%s",
             user.id, title, delivered, approved)


# ----------------------------------------------------------------------------
# Admin commands (private chat with the bot, owner only)
# ----------------------------------------------------------------------------
def owner_only(fn):
    @wraps(fn)
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        owner = get_owner()
        if owner is None:
            await update.effective_message.reply_text(
                "No owner yet. Send /start to claim this bot."
            )
            return
        if update.effective_user.id != owner:
            await update.effective_message.reply_text("⛔ Admin only.")
            return
        return await fn(update, context)

    return wrapper


HELP_TEXT = (
    "<b>Admin commands</b>\n\n"
    "/setmessage <i>text</i> — set the welcome message (or reply to a message with /setmessage)\n"
    "   Placeholders: <code>{first_name}</code> <code>{channel}</code>\n"
    "   Telegram formatting (bold, links, etc.) is kept.\n"
    "/setphoto — reply to a photo to attach it\n"
    "/clearphoto — remove the photo\n"
    "/addbutton <i>Label | https://link</i> — add a link button\n"
    "/clearbuttons — remove all buttons\n"
    "/preview — see exactly what users receive\n"
    "/autoapprove <i>on|off</i> — approve join requests automatically (default: off)\n"
    "/stats — requests, deliveries, users\n"
    "/broadcast — reply to a message to send it to users who pressed Start\n"
    "/help — this list"
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    owner = get_owner()

    if owner is None:
        set_setting("owner_id", str(user.id))
        upsert_user(user, started=True)
        await update.message.reply_text(
            "✅ You are now the owner of this bot.\n\n"
            "Add me as an admin (with the “Invite users” permission) to your private "
            "channel, and turn on “Request admin approval” on its invite link.\n"
        )
        await update.message.reply_text(HELP_TEXT, parse_mode=ParseMode.HTML)
        return

    if user.id == owner:
        upsert_user(user, started=True)
        await update.message.reply_text(HELP_TEXT, parse_mode=ParseMode.HTML)
        return

    # Regular user pressed Start: register them and show the welcome message.
    upsert_user(user, started=True)
    try:
        await send_welcome(context.bot, update.effective_chat.id, user.first_name, "the channel")
    except TelegramError as e:
        log.error("Start reply failed: %s", e)


@owner_only
async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(HELP_TEXT, parse_mode=ParseMode.HTML)


@owner_only
async def set_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    msg = update.message
    new_text = None

    reply = msg.reply_to_message
    if reply is not None:
        if reply.text:
            new_text = reply.text_html
        elif reply.caption:
            new_text = reply.caption_html
    else:
        parts = (msg.text_html or "").split(None, 1)
        if len(parts) == 2:
            new_text = parts[1]

    if not new_text or not new_text.strip():
        await msg.reply_text(
            "Send the message after the command, or reply to a message with /setmessage.\n\n"
            "Example:\n/setmessage Hi {first_name}! Join our VIP group: https://t.me/example"
        )
        return
    if len(new_text) > 3900:
        await msg.reply_text("That message is too long (max about 3900 characters).")
        return

    set_setting("message", new_text)
    await msg.reply_text("✅ Welcome message updated. Use /preview to check it.")


@owner_only
async def set_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    reply = update.message.reply_to_message
    if reply is None or not reply.photo:
        await update.message.reply_text("Reply to a photo with /setphoto.")
        return
    set_setting("photo", reply.photo[-1].file_id)
    await update.message.reply_text("✅ Photo set. Use /preview to check it.")


@owner_only
async def clear_photo(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    del_setting("photo")
    await update.message.reply_text("✅ Photo removed.")


@owner_only
async def add_button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    parts = (update.message.text or "").split(None, 1)
    usage = "Usage: /addbutton Label | https://example.com"
    if len(parts) < 2 or "|" not in parts[1]:
        await update.message.reply_text(usage)
        return
    label, url = (p.strip() for p in parts[1].split("|", 1))
    if not label or not url.lower().startswith(("http://", "https://", "tg://")):
        await update.message.reply_text(usage + "\n(The link must start with https://)")
        return
    buttons = get_buttons()
    if len(buttons) >= MAX_BUTTONS:
        await update.message.reply_text(f"Maximum {MAX_BUTTONS} buttons. Use /clearbuttons first.")
        return
    buttons.append([label[:60], url])
    set_setting("buttons", json.dumps(buttons))
    await update.message.reply_text("✅ Button added. Use /preview to check it.")


@owner_only
async def clear_buttons(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    del_setting("buttons")
    await update.message.reply_text("✅ All buttons removed.")


@owner_only
async def preview(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    try:
        await send_welcome(context.bot, update.effective_chat.id, user.first_name, "Your Channel")
    except TelegramError as e:
        await update.message.reply_text(f"⚠️ Telegram rejected this message: {e}")


@owner_only
async def autoapprove(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    arg = (context.args[0].lower() if context.args else "")
    if arg in ("on", "off"):
        set_setting("autoapprove", arg)
        state = "ON — requests are approved right after the message is sent" if arg == "on" \
            else "OFF — requests stay pending for you to approve"
        await update.message.reply_text(f"✅ Auto-approve is {state}.")
    else:
        current = get_setting("autoapprove", "off").upper()
        await update.message.reply_text(f"Auto-approve is {current}. Use /autoapprove on or /autoapprove off.")


@owner_only
async def stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    with closing(db()) as c:
        total = c.execute("SELECT COUNT(*) n FROM requests").fetchone()["n"]
        delivered = c.execute("SELECT COUNT(*) n FROM requests WHERE delivered = 1").fetchone()["n"]
        approved = c.execute("SELECT COUNT(*) n FROM requests WHERE approved = 1").fetchone()["n"]
        users = c.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
        started = c.execute("SELECT COUNT(*) n FROM users WHERE started = 1 AND blocked = 0").fetchone()["n"]
        per_chat = c.execute(
            "SELECT chat_title, COUNT(*) n FROM requests GROUP BY chat_id ORDER BY n DESC LIMIT 10"
        ).fetchall()
    lines = [
        "<b>Stats</b>",
        f"Join requests: {total}",
        f"Messages delivered: {delivered}",
        f"Auto-approved: {approved}",
        f"Unique users: {users}",
        f"Users reachable for broadcast: {started}",
    ]
    if per_chat:
        lines.append("\n<b>Top channels</b>")
        lines += [f"• {html.escape(r['chat_title'] or '?')}: {r['n']}" for r in per_chat]
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)


async def run_broadcast(app, admin_chat: int, src_chat: int, src_msg_id: int, ids: list[int]) -> None:
    ok = failed = 0
    for uid in ids:
        try:
            await app.bot.copy_message(chat_id=uid, from_chat_id=src_chat, message_id=src_msg_id)
            ok += 1
        except RetryAfter as e:
            await asyncio.sleep(e.retry_after + 1)
            try:
                await app.bot.copy_message(chat_id=uid, from_chat_id=src_chat, message_id=src_msg_id)
                ok += 1
            except TelegramError:
                failed += 1
        except Forbidden:
            mark_blocked(uid)
            failed += 1
        except TelegramError:
            failed += 1
        await asyncio.sleep(0.05)  # stay well under Telegram's rate limit
    try:
        await app.bot.send_message(admin_chat, f"📣 Broadcast finished.\nSent: {ok}\nFailed: {failed}")
    except TelegramError:
        pass


@owner_only
async def broadcast(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    src = update.message.reply_to_message
    if src is None:
        await update.message.reply_text(
            "Reply to the message you want to send with /broadcast.\n"
            "It goes only to people who pressed Start on this bot."
        )
        return
    with closing(db()) as c:
        ids = [r["user_id"] for r in c.execute(
            "SELECT user_id FROM users WHERE started = 1 AND blocked = 0"
        ).fetchall()]
    if not ids:
        await update.message.reply_text("No reachable users yet (nobody has pressed Start).")
        return
    await update.message.reply_text(f"📣 Sending to {len(ids)} users…")
    context.application.create_task(
        run_broadcast(context.application, update.effective_chat.id, src.chat_id, src.message_id, ids)
    )


# ----------------------------------------------------------------------------
# Plumbing
# ----------------------------------------------------------------------------
async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    log.error("Unhandled error", exc_info=context.error)


async def post_init(app) -> None:
    me = await app.bot.get_me()
    log.info("Bot started as @%s", me.username)
    await app.bot.set_my_commands([BotCommand("start", "Start / show admin help")])


def main() -> None:
    token = os.getenv("BOT_TOKEN", "").strip()
    if not token:
        raise SystemExit("BOT_TOKEN is not set. Add it as an environment variable.")

    init_db()
    log.info("Database at %s", DB_PATH)

    app = (
        ApplicationBuilder()
        .token(token)
        .concurrent_updates(True)  # a long broadcast must never block join requests
        .post_init(post_init)
        .build()
    )

    private = filters.ChatType.PRIVATE
    app.add_handler(ChatJoinRequestHandler(on_join_request))
    app.add_handler(CommandHandler("start", start, filters=private))
    app.add_handler(CommandHandler("help", help_cmd, filters=private))
    app.add_handler(CommandHandler("setmessage", set_message, filters=private))
    app.add_handler(CommandHandler("setphoto", set_photo, filters=private))
    app.add_handler(CommandHandler("clearphoto", clear_photo, filters=private))
    app.add_handler(CommandHandler("addbutton", add_button, filters=private))
    app.add_handler(CommandHandler("clearbuttons", clear_buttons, filters=private))
    app.add_handler(CommandHandler("preview", preview, filters=private))
    app.add_handler(CommandHandler("autoapprove", autoapprove, filters=private))
    app.add_handler(CommandHandler("stats", stats, filters=private))
    app.add_handler(CommandHandler("broadcast", broadcast, filters=private))
    app.add_error_handler(on_error)

    # chat_join_request updates are NOT delivered unless requested explicitly.
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
