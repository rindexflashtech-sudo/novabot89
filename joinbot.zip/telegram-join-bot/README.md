# Join-Request Welcome Bot

When someone taps **Request to join** on your private channel or group, this bot
instantly sends them a private message that you can edit anytime from Telegram.
The only secret it needs is the bot token.

## 1. Create the bot
1. Open [@BotFather](https://t.me/BotFather), send `/newbot`, and copy the token.

## 2. Deploy on Railway
1. Push this folder to a GitHub repo.
2. In Railway: **New Project → Deploy from GitHub repo**, pick the repo.
3. Open the service → **Variables** → add `BOT_TOKEN` = your token.
4. **Recommended:** open the service → **Settings → Volumes → Add Volume** (any mount path, e.g. `/data`).
   Without a volume, your saved message, buttons and stats reset on every redeploy.
   The bot detects the volume automatically; no extra variable is needed.
5. Make sure the service runs **one** instance only (two instances of the same bot conflict).
6. Check **Deployments → Logs** for `Bot started as @yourbot`.

## 3. Claim the bot
Send `/start` to your bot in a private chat. The first person to do this becomes the owner.
To lock it to a specific account instead, set the optional variable `OWNER_ID` to your numeric Telegram ID.

## 4. Connect your channel
1. Add the bot to your private channel/group as **admin** with the **Invite users** permission.
2. Channel → Manage → Invite Links → create a link with **Request admin approval** turned **on**.
3. Share that link. Every person who taps *Request to join* gets your message.

## Admin commands (private chat with the bot)
| Command | What it does |
|---|---|
| `/setmessage text` | Set the welcome message, or reply to any message with `/setmessage` to copy its formatting |
| `/setphoto` | Reply to a photo to attach it |
| `/clearphoto` | Remove the photo |
| `/addbutton Label \| https://link` | Add a link button |
| `/clearbuttons` | Remove all buttons |
| `/preview` | See exactly what users receive |
| `/autoapprove on\|off` | Approve requests automatically (default **off**; requests stay pending) |
| `/stats` | Requests, deliveries, users |
| `/broadcast` | Reply to a message to send it to everyone who pressed Start |

Placeholders in the message: `{first_name}` and `{channel}`.

## Good to know
- The bot can message a requester without them ever starting it, but only for about 5 minutes after the request. That is how the instant message works.
- `/broadcast` reaches only people who pressed **Start** on the bot. To collect them, add a button such as
  `/addbutton Get updates | https://t.me/YourBotUsername?start=1`.
- One welcome message is sent per request. Telegram can throttle bots that message people who did not ask to hear from them.
- Run one bot per token. Never commit your token; use Railway variables.

## Run locally
```bash
pip install -r requirements.txt
export BOT_TOKEN=your_token   # Windows PowerShell: $env:BOT_TOKEN="your_token"
python bot.py
```
